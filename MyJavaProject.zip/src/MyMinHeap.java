public class MyMinHeap<E extends Comparable<E>> {
    private MyArrayList<E> heap = new MyArrayList<>();

    public void add(E element) {
        heap.add(element);
        siftUp(heap.size() - 1);
    }

    public E extractMin() {
        if (heap.isEmpty()) return null;
        E result = heap.get(0);
        E last = heap.remove(heap.size() - 1);
        if (!heap.isEmpty()) {
            // Симуляция set(0, last) — только демонстрация
            heap.add(0, last);  // Метод add(int, E) можно реализовать
            siftDown(0);
        }
        return result;
    }

    private void siftUp(int index) {
        while (index > 0) {
            int parent = (index - 1) / 2;
            if (heap.get(index).compareTo(heap.get(parent)) >= 0) break;
            swap(index, parent);
            index = parent;
        }
    }

    private void siftDown(int index) {
        int size = heap.size();
        while (index * 2 + 1 < size) {
            int left = index * 2 + 1, right = index * 2 + 2, min = left;
            if (right < size && heap.get(right).compareTo(heap.get(left)) < 0) min = right;
            if (heap.get(index).compareTo(heap.get(min)) <= 0) break;
            swap(index, min);
            index = min;
        }
    }

    private void swap(int i, int j) {
        E temp = heap.get(i);
        heap.add(i, heap.get(j));
        heap.add(j, temp);
    }
}